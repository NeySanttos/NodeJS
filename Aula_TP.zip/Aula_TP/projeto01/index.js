import chalk from 'chalk';//importando a biblioteca chalk, de colorir
import fs from 'fs';//importando biblioteca fs

function extraiLinks(texto) {
    const regex = /\[([^\]]*)\]\((https?:\/\/[^$#\s].[^\s]*)\)/gm// regec é expressão regular, filtro com o tipo de dado q se pede
    const arrayResultados = [];

    let temp;//variavel q se trata apenas em escolpo
    while((temp = regex.exec(texto))!= null) {
        arrayResultados.push({ [temp[1]] : [temp[2]]})
    }
    return arrayResultados.length === 0 ? "Não há links" : arrayResultados; //ternario, se o resultado for 0 escreve a mensagem
}

function trataErro(erro){
    throw new Error(chalk.bgRed(erro.code, "ARQUIVO NÃO ENCONTRADO!"));//se der erro vai pintar vermelho
}


async function pegaArquivo(caminhoDoArquivo) {// promessa asincrona, retorna quando concluir//
    try{    
        const texto = await fs.promises.readFile(caminhoDoArquivo,'utf-8')//; retorno que chega na conclusão
       return(extraiLinks(texto))
    } 
    catch(erro) {
      trataErro(erro)
    }
}

export default pegaArquivo;



